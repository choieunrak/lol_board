package com.eunrak.GameLol.disp;

public class Disp {
private static String TITLE = "〓〓〓〓〓〓〓〓〓〓 롤 게시판 〓〓〓〓〓〓〓〓〓";
private static String TITLE_BAR = "〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓";

private static String MAINMENU_BAR = "↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓";
private static String MAINMENU = "[1, 챔피언 정보 2, 자유게시판 3, 글 읽기 4, 글 작성 5, 글 삭제 0, 관리자 X, 프로그램 종료]";

public static void showTitle() {
	System.out.println(TITLE_BAR);
	System.out.println(TITLE);
	System.out.println(TITLE_BAR);
}
	
	public static void showMainManu() {
		System.out.println(MAINMENU_BAR);
		System.out.println(MAINMENU);
}
}
